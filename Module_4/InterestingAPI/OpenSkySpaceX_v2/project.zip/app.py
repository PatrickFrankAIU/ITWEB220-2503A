from flask import Flask, render_template, request
import requests
import pandas as pd
from datetime import datetime
import dateutil.parser
import pytz

app = Flask(__name__)

# Global cache to store full-day flight data
cached_flights = None

def fetch_launches():
    url = "https://ll.thespacedevs.com/2.2.0/launch/upcoming/"

    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        launches = response.json().get("results", [])

        local_tz = pytz.timezone("America/Chicago")

        def format_time_range(utc_start, utc_end):
            dt_start_utc = dateutil.parser.isoparse(utc_start)
            dt_end_utc = dateutil.parser.isoparse(utc_end)
            dt_start_local = dt_start_utc.astimezone(local_tz)
            dt_end_local = dt_end_utc.astimezone(local_tz)

            # Format date and time separately for UTC and local
            utc_str = f"{dt_start_utc.strftime('%Y-%m-%d %H:%M')} → {dt_end_utc.strftime('%H:%M')}"
            local_str = f"{dt_start_local.strftime('%Y-%m-%d %I:%M %p').lstrip('0')} → {dt_end_local.strftime('%I:%M %p').lstrip('0')}"

            return f"UTC: {utc_str} | IAH Local: {local_str}"

        return [
            {
                "id": launch["id"],
                "name": launch["name"],
                "window_start": launch["window_start"],
                "window_end": launch["window_end"],
                "display": f"{launch['rocket']['configuration']['name']} | {launch['mission']['name']} ({format_time_range(launch['window_start'], launch['window_end'])})"
            }
            for launch in launches
            if launch.get("rocket") and launch.get("mission")
        ]

    except Exception as e:
        print("Error fetching launches:", e)
        return []

def fetch_full_day_flights():
    headers = {
        "X-RapidAPI-Key": "f5698355camsh0adc2a3c5dc04d6p168bdfjsn835b4e3502ff",
        "X-RapidAPI-Host": "aerodatabox.p.rapidapi.com"
    }

    url_early = "https://aerodatabox.p.rapidapi.com/flights/airports/iata/IAH/2025-06-13T00:00/2025-06-13T12:00"
    url_late = "https://aerodatabox.p.rapidapi.com/flights/airports/iata/IAH/2025-06-13T12:00/2025-06-13T23:59"

    params = {
        "withLeg": "true",
        "direction": "Departure",
        "withCancelled": "true",
        "withCodeshared": "true",
        "withCargo": "true",
        "withPrivate": "true",
        "withLocation": "false"
    }

    all_flights = []

    for url in [url_early, url_late]:
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
        flights = response.json().get("departures", [])
        all_flights.extend(flights)

    return all_flights

@app.route('/')
def index():
    global cached_flights

    # Only fetch flights once
    if cached_flights is None:
        cached_flights = fetch_full_day_flights()

    launches = fetch_launches()
    selected_launch_id = request.args.get("launch")

    selected_window_start = None
    selected_window_end = None
    selected_launch_date = None

    for launch in launches:
        if launch["id"] == selected_launch_id:
            selected_window_start = dateutil.parser.isoparse(launch["window_start"])
            selected_window_end = dateutil.parser.isoparse(launch["window_end"])
            selected_launch_date = selected_window_start.date()
            break

    rows = []
    for f in cached_flights:
        dep = f.get("departure", {})
        arr = f.get("arrival", {})
        aircraft = f.get("aircraft", {})
        airline = f.get("airline", {})

        dep_local_str = dep.get("scheduledTime", {}).get("local")
        arr_utc_str = arr.get("scheduledTime", {}).get("utc")

        if not dep_local_str or not arr_utc_str:
            continue

        try:
            dep_local = dateutil.parser.isoparse(dep_local_str)  # includes timezone offset
        except ValueError:
            continue

        # If launch is selected, filter by dep_local vs launch window (converted automatically)
        if selected_window_start and selected_window_end:
            if dep_local.date() != selected_launch_date:
                continue
            if not (selected_window_start <= dep_local <= selected_window_end):
                continue

        row = {
            "Flight Number": f.get("number", "N/A"),
            "Airline": airline.get("name", "N/A"),
            "Status": f.get("status", "N/A"),

            "Departure Terminal": dep.get("terminal", "N/A"),
            "Departure UTC": dep.get("scheduledTime", {}).get("utc", "N/A"),
            "Departure Local": dep_local_str,

            "Arrival Airport": arr.get("airport", {}).get("name", "N/A"),
            "Arrival City": arr.get("airport", {}).get("municipalityName", "N/A"),
            "Arrival UTC": arr_utc_str,
            "Arrival Local": arr.get("scheduledTime", {}).get("local", "N/A"),

            "Aircraft Model": aircraft.get("model", "N/A"),
        }
        rows.append(row)

    df = pd.DataFrame(rows)
    html_table = df.to_html(classes="table table-bordered table-striped", index=False, escape=False)

    return render_template("index.html", table=html_table, launches=launches, selected_launch_id=selected_launch_id)

if __name__ == '__main__':
    app.run(debug=True)
